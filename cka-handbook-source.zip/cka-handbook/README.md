# Kubernetes CKA — Sổ tay tiếng Việt

Website sách trực tuyến, lấy cảm hứng bố cục từ AmazonECS-for-DevOps. Source được viết mới bằng HTML/CSS/JavaScript, không cần framework hay bước build.

## Chạy local

Cần Python 3:

```sh
cd cka-handbook
python3 -m http.server 4173 --directory dist
```

Mở http://localhost:4173. Có thể dùng `npm run dev` nếu đã cài Node.js/npm. Kiểm tra cú pháp bằng `npm run check`.

## Cấu trúc

- `dist/index.html`: khung giao diện, dùng được làm trang GitHub Pages.
- `dist/style.css`: giao diện sách, sáng/tối, responsive, hỗ trợ giảm chuyển động.
- `dist/content.js`: toàn bộ nội dung, thông tin từng phần và bài học.
- `dist/app.js`: router hash, mục lục, tìm kiếm, tiến độ, cỡ chữ và hiệu ứng.
- `.openai/hosting.json`: định danh bản xem trước Sites; không chứa credential.

Đường dẫn: `#/` là trang bìa; `#/phan/1` là phần mở đầu; `#/bai/1` là bài học. Mỗi phần đều có mở đầu, mục tiêu và danh sách bài. Dùng ←/→ để chuyển trang khi không nhập văn bản. Đánh dấu hoàn thành là thao tác chủ động; việc mở bài không tự đánh dấu hoàn thành.

Tiến độ, theme, cỡ chữ, hiệu ứng và vị trí đọc gần nhất lưu trong localStorage của trình duyệt, không đồng bộ giữa các máy. Reset chỉ xóa tiến độ hoàn thành và có hộp xác nhận. Trang không cần tài khoản hoặc backend.

## Biên tập nội dung

Sửa mảng `CHAPTERS` trong `content.js`. Mỗi phần có `title`, `en`, `intro`, `goals` và `lessons`. Mỗi bài có 8 mục: tiêu đề, giải thích, danh sách điểm chính, lệnh, bài tập, tiêu chí kiểm tra, lưu ý, URL/đường dẫn tài liệu. ID bài được gán tuần tự; nếu cần giữ bookmark lâu dài, tránh chèn bài vào giữa danh sách đang phát hành hoặc chuyển sang ID cố định.

Nội dung là ghi chú tiếng Việt tự biên soạn theo chủ đề CKA để học kèm khóa Certified Kubernetes Administrator with Practice Tests của Mumshad Mannambeth/KodeKloud. Không phải bản sao, bản dịch, transcript, tài liệu chính thức hoặc toàn bộ 312 lecture Udemy. Không có video, bài thi thật hay tài nguyên trả phí. Các tình huống thực hành là bài tập tự soạn, không phải terminal tương tác trong website.

Các URL tham khảo tới Kubernetes/Helm được gắn trong từng bài. Một số lệnh yêu cầu cluster, addon hoặc quyền quản trị node; không thể chạy trực tiếp trong trang web. Thay `<...>` bằng giá trị thật của môi trường lab. Không áp dụng máy móc lên production. Đối chiếu hướng dẫn đúng phiên bản cho kubeadm, etcd và CNI.

## Deploy GitHub Pages

1. Đưa **nội dung bên trong `dist/`** lên thư mục gốc của repository GitHub Pages (hoặc thư mục `docs/`).
2. Trong Settings → Pages, chọn branch và thư mục tương ứng.
3. Mọi asset dùng đường dẫn tương đối, mọi route dùng hash, nên không cần rewrite hay thay base URL khi deploy dưới subpath.

Có thể deploy thư mục `dist/` lên bất kỳ static host nào. Không cần API key hoặc biến môi trường. Fonts từ Google Fonts có fallback hệ thống nếu offline.
